---
name: aprender-de-un-video
description: "Resume un video de YouTube a partir de su transcripción real, con ejemplos y cifras. Úsalo con un enlace de YouTube, 'resume este video' o una transcripción pegada."
---

# Aprender de un video

Lo útil de un video de una hora, en dos minutos, con las palabras reales de quien habla. **Sin transcripción no hay resumen:** nunca resumas por el título o la descripción.

## Conseguir la transcripción

**En el chat:** pide que la pegue. En YouTube desde el computador: abrir la descripción del video, "Mostrar transcripción", seleccionar todo y copiar. Si un enlace no te deja leer la transcripción, dilo y da estos pasos.

**En Claude Code:** con `yt-dlp` instalado (compruébalo con `yt-dlp --version`; si falta, ofrece instalarlo):
1. Datos del video: `yt-dlp --skip-download --print "%(title)s | %(channel)s | %(duration_string)s | %(language)s" "ENLACE"`
2. Subtítulos en el idioma original: `yt-dlp --skip-download --write-subs --write-auto-subs --sub-langs "es.*,en.*" --sub-format vtt -o "video.%(ext)s" "ENLACE"`. Prefiere los escritos por el autor a los automáticos, y el idioma original al traducido.
3. Limpia el archivo: quita líneas repetidas y conserva una marca de tiempo cada tanto.

Si no hay subtítulos, dilo y detente. Si YouTube limita las descargas, espera y prueba una vez más.

## Cómo resumir

- Pregunta para qué lo quiere, si no es obvio.
- **Conserva** cada ejemplo, cifra, nombre y herramienta: es lo que tiene valor.
- No agregues información de fuera. Si algo parece falso o está vendiendo algo, dilo en una sección aparte.
- Los subtítulos automáticos escriben mal los nombres: marca los dudosos.

## Entrega

```
# [Título], [canal], [duración]
## En tres líneas
## Ideas principales (cada una con su ejemplo y el minuto)
## Qué puedes hacer en tu negocio (lo que el video dice, no lo que yo agrego)
## Herramientas, personas y enlaces mencionados
## Para tomar con cuidado
## ¿Conviene verlo completo? Sí, no, o solo de tal minuto a tal minuto
```

Si el valor está en lo que se ve en pantalla, avisa que la transcripción no lo capta.
