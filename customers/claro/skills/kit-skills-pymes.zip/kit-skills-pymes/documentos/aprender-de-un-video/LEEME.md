# aprender-de-un-video

Lo útil de un video de una hora, en dos minutos, con ejemplos, cifras y el minuto de cada idea.

**Cómo pedirlo:** "Resume este video" y pegas la transcripción (en el chat) o el enlace (en Claude Code).

**Ejemplo:** "Resume este video, tengo una tienda de ropa y quiero saber qué puedo aplicar."

**Dónde funciona:** en el chat, pegando la transcripción. En **Claude Code**, con el enlace (necesita yt-dlp, gratis; Claude te ayuda a instalarlo).
