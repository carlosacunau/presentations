---
name: armar-presentacion
description: "Arma una presentación para el banco, un cliente o socios a partir de notas. Úsalo con 'hazme una presentación', 'láminas', 'PowerPoint' o 'pitch'."
---

# Armar una presentación

De notas sueltas a una presentación que se entiende sin explicaciones.

## Paso 1. Tres preguntas

1. ¿Quién la va a ver y qué tiene que decidir?
2. ¿Cuánto tiempo hay? ¿Se presenta o se envía?
3. ¿Qué material tienes? (notas, cifras, fotos, logo, presentación anterior)

Regla de tamaño: cerca de una lámina por minuto, máximo doce salvo que pida más.

## Paso 2. El guion antes que el diseño

Entrega primero solo los títulos, cada uno como **frase completa que dice la conclusión** ("Vendemos 30% más los sábados", no "Ventas"). Leídos de corrido, deben contar la historia. Junto a cada título, de qué dato sale.

Órdenes que funcionan:
- **Banco:** qué hago, cuánto vendo, para qué quiero el crédito, cómo lo pago, qué respaldo hay.
- **Cliente:** su problema, qué pasa si sigue igual, qué propongo, prueba, precio y siguiente paso.
- **Socios:** resultado, qué funcionó, qué no, decisión que necesito.

Pide su OK con el guion antes de seguir.

## Paso 3. Las láminas

- Una idea por lámina, menos de 40 palabras.
- Un gráfico cuando hay cifras que comparar; si es un solo número, el número grande.
- Todo dato con fuente. Dato que falte: `[FALTA: ventas de octubre]`. Nunca lo inventes ni lo redondees a favor.
- Notas para hablar en cada lámina, en lenguaje oral.

Si puedes crear archivos, genera el PowerPoint con letra de 18 puntos o más y los colores de su logo. Después revisa que no haya texto cortado ni encimado. Si no puedes, entrega el contenido lámina por lámina para copiar.

## Paso 4. Ensayo

Las cinco preguntas difíciles que le van a hacer, con una respuesta corta para cada una basada en su material, y la lista de datos por confirmar.
