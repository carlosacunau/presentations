# armar-presentacion

Tu presentación para el banco, un cliente o tus socios, desde tus notas, con lo que dices en cada lámina y las preguntas difíciles.

**Cómo pedirlo:** "Hazme una presentación" y pegas tus notas.

**Ejemplo:** "Hazme una presentación de 8 minutos para el banco. Quiero $15 millones para un segundo horno" con tus ventas del año.
