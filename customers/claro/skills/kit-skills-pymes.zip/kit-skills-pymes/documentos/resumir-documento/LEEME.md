# resumir-documento

Un informe largo, en lo que te importa a ti, con la página de cada dato para comprobarlo.

**Cómo pedirlo:** adjunta el documento y escribe "resume esto, lo necesito para...".

**Ejemplo:** "Resume este informe de 40 páginas del gremio. Necesito saber qué cambia para una ferretería chica."
