---
name: revisar-contrato
description: "Explica un contrato antes de firmarlo: obligaciones, costos, plazos, salidas y preguntas. Úsala con 'revisa este contrato', 'antes de firmar' o 'letra chica'."
---

# Revisar un contrato

La letra chica de un contrato, antes de firmar. Ayuda a entender y a preguntar bien. **No es asesoría legal ni dice "firma" o "no firmes".**

## Antes

Pregunta: ¿qué parte eres tú?, ¿qué te prometieron de palabra?, ¿qué te preocupa? Sugiere tapar RUT, direcciones y cuentas. Confirma que tienes el contrato completo con sus anexos; si falta alguno, anótalo como primer riesgo.

## Qué buscar

| Tema | Pregunta |
|---|---|
| Objeto | ¿Está escrito lo que te prometieron? |
| Plata | Precio, reajustes, IVA, cobros extra, intereses, quién paga qué |
| Plazo | Inicio, término, renovación automática y cómo se evita |
| Salida | Quién puede terminarlo, con cuánto aviso y a qué costo |
| Multas | Por qué, cuánto, si corren para las dos partes |
| Garantías | Boleta, pagaré, aval, garantía personal |
| Responsabilidad | Qué pasa si algo sale mal, topes |
| Exclusividad | Qué dejas de poder hacer |
| Propiedad y datos | De quién es lo creado, uso de datos personales |
| Cambios | Si la otra parte puede cambiarlo sola |
| Conflictos | Ley aplicable, tribunal o arbitraje |

## Entrega

1. **Qué estás aceptando**, en cinco líneas simples.
2. **Tus obligaciones y fechas** en una tabla con número de cláusula.
3. **Revisa esto antes de firmar:** ALTO, MEDIO o BAJO. Cita textual breve, cláusula, qué significa en la práctica con un ejemplo en pesos si se puede, y qué pedir.
4. **Lo que falta:** lo prometido de palabra que no está escrito.
5. **Preguntas para la otra parte,** listas para copiar.
6. **Preguntas para un abogado.** Siempre que haya garantía personal, propiedad, socios, trabajadores, montos importantes o multas altas.

## Reglas

- Cita la cláusula. Sin cláusula no hay hallazgo.
- Si una frase admite dos lecturas, muestra ambas.
- No cites artículos de ley de memoria.
- Aclara qué parte no pudiste leer.
- Si propones una redacción, márcala "para conversar con un abogado".
