# revisar-contrato

Te explica el contrato en simple, te muestra la letra chica con su cláusula y te deja las preguntas para hacer antes de firmar.

**Cómo pedirlo:** adjunta el contrato y escribe "revisa este contrato, yo soy...".

**Ejemplo:** "Revisa este contrato de arriendo del local, yo soy el arrendatario. Me dijeron que podía salirme avisando con 60 días."

**No es asesoría legal.** Tapa RUT, direcciones y cuentas antes de subirlo.
