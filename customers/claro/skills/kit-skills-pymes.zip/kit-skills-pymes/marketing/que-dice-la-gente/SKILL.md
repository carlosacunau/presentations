---
name: que-dice-la-gente
description: "Busca qué se está diciendo este mes de un rubro, producto o marca, con enlaces. Úsala con 'qué dice la gente', 'qué se comenta de', 'tendencias de mi rubro'."
---

# Qué dice la gente

Qué se está diciendo de un rubro, producto o marca en los últimos 30 días, y qué hacer con eso.

**Necesita búsqueda web activada.** Si no está, dilo y detente: de memoria no sirve. La búsqueda no ve todo (muchas redes están cerradas), así que esto es una muestra, no una encuesta.

## Cómo buscar

1. Aclara tema, país y para qué lo quiere. Una sola pregunta si falta algo. Confirma la fecha de hoy.
2. Haz entre 6 y 10 búsquedas con las palabras que usa un cliente, no las del rubro: "problema con", "recomiendan", "cuánto cobran", "alternativa a", más el país o la ciudad.
3. Mira foros, comentarios, reseñas, videos, prensa local y blogs. Prefiere personas a publicidad.
4. Guarda de cada hallazgo: qué dice, dónde, fecha y enlace.

## Filtros

- Más de 30 días: fuera, o marcado "antiguo" si sigue siendo útil.
- Sin fecha visible: dilo.
- Publicidad o nota pagada: márcala.
- Un comentario es una anécdota. Llama "tema" solo a lo que aparece en tres o más fuentes distintas.

## Entrega

1. Lo que está pasando, en cinco líneas.
2. **Temas:** cada uno con cuántas fuentes, una cita corta textual y sus enlaces.
3. **Palabras que usa la gente:** lista para usar en textos y avisos.
4. **Preguntas que se repiten:** cada una puede ser una publicación.
5. **Qué haría yo** (opinión): máximo tres acciones.
6. **Qué no encontré.**

## Límites

No inventes citas, cifras ni porcentajes. No des nombres de personas particulares. Si encontraste poco, entrega poco y dilo.
