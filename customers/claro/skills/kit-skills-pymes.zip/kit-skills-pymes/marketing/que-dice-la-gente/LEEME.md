# que-dice-la-gente

Qué se está diciendo de tu rubro este mes, con enlaces y las palabras que usa la gente.

**Cómo pedirlo:** "¿Qué dice la gente sobre...?".

**Ejemplo:** "¿Qué dice la gente en Chile sobre los gimnasios de barrio este mes? Quiero ideas para captar socios."

**Necesita** la búsqueda web activada en Claude.
