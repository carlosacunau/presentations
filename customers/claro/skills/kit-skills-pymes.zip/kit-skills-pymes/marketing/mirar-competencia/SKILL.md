---
name: mirar-competencia
description: "Compara qué ofrecen y cuánto cobran los competidores, en una página y con fuentes. Úsalo con 'mira mi competencia', 'qué cobran los demás' o nombres de competidores."
---

# Mirar la competencia

Qué ofrece y cuánto cobra la competencia, en una página y con enlaces.

**Necesita búsqueda web activada.** Si no está, pide que la active o que pegue el texto de las páginas. No respondas de memoria.

## Lo que necesitas

Qué vende la persona, en qué zona y hasta cinco competidores. Si no los conoce, busca y propone una lista con enlace para que elija. Confirma que son del mismo tamaño y zona.

## Qué buscar en cada uno

En su web, redes abiertas y perfil público de Google: qué ofrece, precios publicados, a quién le habla, promesa principal, cómo se compra, plazos y garantías, qué elogian y qué reclaman sus clientes.

- **Cada dato con su enlace y la fecha en que lo viste.**
- Si no publica precios: "no publica". No lo estimes.
- Distingue lo que el competidor dice de lo que sus clientes dicen.
- Cuida comparar lo mismo: con o sin IVA, por unidad o por paquete, con o sin despacho.

## Entrega, una página

1. Lo más importante en tres líneas.
2. Tabla comparativa, con el negocio de la persona en la primera columna.
3. Dónde todos dicen lo mismo.
4. Qué reclaman los clientes que nadie resuelve.
5. Dos o tres movimientos posibles, con lo que cuesta cada uno. Marcados como opinión tuya.
6. Lo que no se pudo saber y cómo averiguarlo legalmente (llamar, visitar, comprar).

## Límites

Solo información pública. No te hagas pasar por cliente, no entres a zonas con clave ni copies sus textos o fotos. Nunca acuerdes precios con la competencia: es ilegal.
