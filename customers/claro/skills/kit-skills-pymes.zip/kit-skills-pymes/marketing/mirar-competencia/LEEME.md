# mirar-competencia

Qué ofrece y cuánto cobra tu competencia, en una página y con enlaces.

**Cómo pedirlo:** "Mira mi competencia" y das tu rubro, tu zona y nombres si los sabes.

**Ejemplo:** "Mira mi competencia: lavado de alfombras a domicilio en La Florida y Maipú."

**Necesita** la búsqueda web activada en Claude.
