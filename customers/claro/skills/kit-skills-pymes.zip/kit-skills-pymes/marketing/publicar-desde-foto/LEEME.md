# publicar-desde-foto

Mandas una foto y sale el texto para Instagram, el estado de WhatsApp y la ficha del producto.

**Cómo pedirlo:** adjunta la foto y escribe "publica esto".

**Ejemplo:** "Publica esto: pan de masa madre, $4.500, sale a las 8 y a las 17, en Ñuñoa" con la foto.
