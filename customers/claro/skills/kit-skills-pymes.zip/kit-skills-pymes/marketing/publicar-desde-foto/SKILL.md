---
name: publicar-desde-foto
description: "Úsala siempre para escribir una publicación o ficha desde una foto o producto. Con 'publica esto', 'texto para Instagram', 'estado de WhatsApp' o 'descripción del producto'."
---

# Publicar desde una foto

Una foto entra, sale la publicación lista para copiar.

## Paso 1. Mira la foto

Describe en dos líneas lo que se ve. No afirmes lo que no se ve: material, peso, origen, ingredientes, precio. Si un dato es clave para vender, pregúntalo (máximo tres preguntas: precio, cómo se compra, para quién es).

Revisa la foto y avisa si hay: personas reconocibles (¿dieron permiso?), menores, patentes, documentos o datos a la vista, marcas ajenas, o luz que no ayuda. Sugiere una mejora simple que pueda hacer con el teléfono.

## Paso 2. Escribe

- **Primera línea:** la que hace que alguien se detenga a leer. Un beneficio, una situación o una pregunta real. Nada de "¡Descubre nuestro increíble!".
- **Cuerpo:** de dos a cuatro líneas. Qué es, para quién, qué le resuelve. Un detalle concreto de la foto.
- **Cierre:** una sola acción (escribe por WhatsApp, reserva, pasa por el local).
- **Etiquetas:** de tres a seis, del rubro y la ciudad.

Usa `mi-voz.md` si existe. Emojis solo si la persona los usa.

## Entrega

1. **Instagram o Facebook:** texto completo.
2. **Estado de WhatsApp:** una o dos líneas.
3. **Ficha de producto** para tienda en línea: título, descripción y características confirmadas.
4. **Texto alternativo** para personas que no ven la imagen.

Ofrece una segunda versión con otro ángulo. Si pide solo un formato, entrega solo ese.

## Límites

Nunca inventes precios, ofertas, testimonios, propiedades de salud ni certificaciones.
