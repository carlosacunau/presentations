# semana-de-publicaciones

El plan y los textos de toda la semana, con la lista de fotos que necesitas.

**Cómo pedirlo:** "Hazme las publicaciones de la semana".

**Ejemplo:** "Hazme las publicaciones de la semana. Tengo una veterinaria, quiero llenar las horas de la mañana, puedo publicar tres veces y todos preguntan por la vacuna de los cachorros."
