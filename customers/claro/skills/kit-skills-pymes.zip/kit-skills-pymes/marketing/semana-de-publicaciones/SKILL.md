---
name: semana-de-publicaciones
description: "Planea y escribe las publicaciones de toda la semana. Úsalo con 'publicaciones de la semana', 'qué publico', 'calendario de contenido' o 'ideas para Instagram'."
---

# Semana de publicaciones

Las publicaciones de toda la semana, de una sola vez, con cosas que de verdad pasan en el negocio.

## Paso 1. Seis preguntas, en un solo mensaje

1. ¿Qué quieres que pase esta semana? (vender algo, llenar horas, que te conozcan)
2. ¿Qué hay de nuevo o especial?
3. ¿Qué te preguntaron los clientes últimamente?
4. ¿Qué fotos o videos tienes o puedes sacar?
5. ¿En qué redes y cuántas veces puedes publicar de verdad?
6. ¿Hay fechas, ferias u ofertas confirmadas?

Usa `mi-negocio.md` y `mi-voz.md` si existen y no repitas lo que ya responden. Si dice "elige tú", propone tres publicaciones y sigue.

## Paso 2. Mezcla

De cada cuatro: una que **enseña** (responde una pregunta real), una que **muestra** (cómo se hace, quién lo hace), una que **prueba** (caso o comentario real, con permiso) y una que **vende**. No pongas dos ventas seguidas.

## Paso 3. Entrega

Primero el plan, en una tabla:

| Día | Red | Idea | Tipo | Foto o video que necesitas | Acción |

Después, cada publicación completa: primera línea, texto, cierre, etiquetas, y cómo sacar la foto o grabar el video con el teléfono en menos de diez minutos. Para video corto: guion de 20 a 40 segundos con lo que se ve y lo que se dice.

Al final, una lista única de fotos y videos para sacarlos todos en una tanda.

## Reglas

- Ideas de este negocio, no de cualquiera. Si sirve igual para la competencia, cámbiala.
- Nada de días mundiales de relleno.
- Nunca inventes clientes, testimonios, cifras ni ofertas.
- La hora de publicación es una sugerencia: lo que manda son sus propias estadísticas.

## La semana siguiente

Pide qué funcionó (guardados, mensajes, ventas) y ajusta la mezcla.
