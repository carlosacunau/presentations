# pensar-una-decision

¿Contratas? ¿Abres otro local? Te hace las preguntas difíciles, te lleva la contra y te deja una página para decidir.

**Cómo pedirlo:** "Ayúdame a decidir si...".

**Ejemplo:** "Ayúdame a decidir si contrato un vendedor. Costaría unos $900.000 al mes y hoy vendo yo."

Toma unos 20 minutos. Hazlo con tus números cerca.
