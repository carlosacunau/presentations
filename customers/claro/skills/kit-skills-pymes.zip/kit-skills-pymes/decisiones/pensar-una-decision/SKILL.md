---
name: pensar-una-decision
description: "Ayuda a decidir con método: opciones, supuestos, riesgos y una prueba pequeña. Úsalo con 'ayúdame a decidir', 'no sé si', 'contrato a alguien' o 'abro otro local'."
---

# Pensar una decisión

Para decisiones que cuestan plata o no se deshacen fácil. Claude no decide: ordena, pregunta y discute.

## Reglas

- Una pregunta por turno.
- **No opines al comienzo.** Si opinas primero, la persona razona alrededor de tu opinión.
- No le des la razón por cortesía. Si ya decidió y busca aprobación, dilo con respeto.

## Paso 1. La decisión real

¿Qué tienes que decidir, para cuándo y qué pasa si no haces nada? ¿Se puede deshacer? Si se deshace fácil y cuesta poco, recomienda probar ya y termina aquí.

## Paso 2. Opciones

Mínimo tres, incluidas "no hacer nada" y "una versión más pequeña". Pregunta qué tendría que ser verdad para que cada una fuera la mejor.

## Paso 3. Supuestos

| Supuesto | ¿Lo sé o lo creo? | ¿Qué pasa si es falso? | Cómo lo compruebo barato |

Trabaja los dos que más daño hacen si son falsos.

## Paso 4. Números

Costo de entrada, costo mensual, cuánto tarda en pagarse, cuánto aguanta la caja si sale mal. Tres escenarios con los números de la persona. Lo que falte queda como supuesto visible.

## Paso 5. El fracaso imaginado

"Pasó un año y salió mal. ¿Qué pasó?". Primero ella, después agregas tú. Para las tres causas más probables: señal temprana y qué hacer.

## Paso 6. En contra

Escribe el mejor argumento contra la opción que más le gusta, en serio.

## Entrega, una página

Decisión y fecha límite, opciones comparadas, lo que se sabe y lo que se cree, riesgos con señal temprana, **prueba pequeña** que se puede hacer en dos semanas, condición para parar ("si en 90 días no pasa X, cierro"), y tu opinión al final, con cuánta confianza y qué te haría cambiarla.

Para temas legales, tributarios, laborales o de salud, indica qué profesional consultar.
