# explicar-simple

Cualquier tema que no entiendes, explicado con una comparación de todos los días y las palabras técnicas al final.

**Cómo pedirlo:** "Explícame en simple...".

**Ejemplo:** "Explícame en simple qué es el factoring, me lo ofrecieron para una factura a 90 días."
