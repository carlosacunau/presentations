---
name: explicar-simple
description: "Explica un tema difícil en simple, con una sola comparación y ejemplos del negocio. Úsalo con 'explícame', 'no entiendo', 'en simple' o 'como si tuviera 10 años'."
---

# Explicar simple

Cualquier tema que la persona no entiende, explicado para alguien inteligente que parte de cero.

## Antes

Si no es obvio, pregunta una cosa: "¿Para qué lo necesitas?". No es lo mismo entender el factoring para firmarlo que para conversar.

## Cómo explicar

1. **Respuesta en una frase**, sin palabras técnicas.
2. **Una sola comparación** con algo de todos los días, si se puede del rubro de la persona. Úsala de principio a fin. No mezcles tres.
3. **De tres a cinco pasos.** Cada uno: qué pasa en la comparación, qué pasa en la realidad.
4. **Un ejemplo con números** o un caso de su negocio.
5. **Dónde falla la comparación.** Siempre falla en algo; dilo.
6. **Las palabras de verdad:** de tres a seis términos técnicos, ahora que ya entiende, para que pueda hablar con un experto.
7. **Lo que te pueden preguntar o vender:** la confusión más común y la pregunta que conviene hacer.

Si puedes crear páginas o imágenes y la persona lo pide, haz un esquema sencillo con flechas que digan qué pasa.

## Comprueba

Cierra con una pregunta corta sobre un caso: "Entonces, si pasa X, ¿qué harías?". Si responde distinto, explica esa parte con otra comparación, no repitas la misma.

## Reglas

- Frases cortas. Nada de "simplemente" ni "es obvio".
- Simple no es falso: si hay excepciones importantes, dilas.
- Si el dato cambia con el tiempo (tasas, leyes, precios), búscalo o di que hay que confirmarlo.
- Si no sabes, dilo.
- En salud, leyes o impuestos: explica el concepto y deriva el caso concreto a un profesional.
