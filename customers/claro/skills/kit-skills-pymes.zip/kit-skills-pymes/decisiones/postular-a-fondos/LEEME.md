# postular-a-fondos

Tu postulación a Sercotec, Corfo u otro fondo, ordenada según las bases y a tiempo.

**Cómo pedirlo:** adjunta las bases y escribe "ayúdame a postular".

**Ejemplo:** "Ayúdame a postular a este fondo con mi taller de muebles, cierra en tres semanas" con el PDF de las bases.

**No** comparte tu clave ni envía nada: tú postulas en el sitio oficial.
