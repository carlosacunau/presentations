---
name: postular-a-fondos
description: "Ordena una postulación a fondos como Sercotec o Corfo a partir de las bases. Úsala con 'postular', 'Sercotec', 'Corfo', 'capital semilla' o 'bases de un fondo'."
---

# Postular a un fondo

La postulación ordenada y a tiempo. **Todo sale de las bases oficiales vigentes**, nunca de memoria: los requisitos, montos y fechas cambian en cada convocatoria.

## Paso 1. Las bases

Pide el PDF o el texto de las bases. Si no las tiene y hay búsqueda web, busca solo en sitios oficiales (sercotec.cl, corfo.cl, o el de la institución) y entrega el enlace y la fecha. Si no están publicadas, no sigas con supuestos: ofrece preparar el material general.

Avisa: postular en el sitio oficial se hace con la cuenta de la persona. No pidas su clave ni entregues dinero a quien prometa un cupo.

## Paso 2. ¿Puedo postular?

| Requisito (con página) | ¿Lo cumplo? Sí, no, por confirmar | Prueba o documento |

Si hay un "no" excluyente, dilo de inmediato y detente.

## Paso 3. Cómo evalúan

Tabla de criterios con su puntaje y qué responde cada uno. El esfuerzo va donde está el puntaje.

## Paso 4. Entrevista

Una pregunta por turno: problema, cliente, qué hace distinto, ventas o pruebas, qué compraría con la plata, qué cambiaría en un año, quién hace qué. Usa `mi-negocio.md` si existe.

## Paso 5. Borrador

- Respuesta por pregunta del formulario, dentro del límite de caracteres (cuéntalos).
- Con las palabras de la persona. Nada de "solución innovadora y disruptiva".
- Cada afirmación con su dato. Lo que falte: `[FALTA: ventas 2025]`. **Nunca inventes cifras, clientes ni empleos:** es causa de rechazo y puede tener consecuencias legales.
- Presupuesto: solo gastos que las bases permiten, con página, respetando topes y aporte propio. Suma revisada.

## Paso 6. Calendario

Hacia atrás desde el cierre, con dos días de margen. Documentos, quién los emite y cuánto demoran.

## Entrega final

Lista de requisitos, borrador, presupuesto, calendario y una revisión como evaluador: nota por criterio, lo más débil y cómo mejorarlo con lo que hay. Aclara que nadie puede asegurar la adjudicación.
