# revisar-herramienta

Antes de pagar una app, sabes si te sirve, cuánto cuesta de verdad y qué tan segura se ve: verde, amarillo o rojo.

**Cómo pedirlo:** "Revisa esta app" y das el nombre o el enlace.

**Ejemplo:** "Revisa esta app de agenda para mi barbería, somos tres y hoy usamos un cuaderno" con el enlace.

**Necesita** la búsqueda web activada en Claude.
