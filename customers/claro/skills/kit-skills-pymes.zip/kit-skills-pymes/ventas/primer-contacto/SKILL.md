---
name: primer-contacto
description: "Escribe un primer mensaje distinto para cada cliente potencial a partir de datos reales. Úsalo con 'primer mensaje', 'contactar clientes' o una lista de posibles clientes."
---

# Primer contacto

Un mensaje por cliente potencial, con una razón real para escribirle. Si el mensaje le sirve igual a otra empresa, está mal.

## Lo que necesitas

1. Qué vende la persona, a quién y qué resultado logra (usa `mi-negocio.md` si existe).
2. La lista: nombre, empresa, rubro y todo dato público disponible (web, Instagram, una noticia, cómo se conocieron).
3. Canal: correo, WhatsApp, LinkedIn o Instagram.

Si tienes búsqueda web, úsala para encontrar un dato público y reciente de cada empresa, y guarda el enlace. Si no encuentras nada confiable, dilo: "sin dato, conviene mirar su página antes de escribir". **Nunca inventes un elogio ni un dato.**

## Estructura del mensaje

1. **Por qué tú:** el dato concreto sobre esa empresa.
2. **Puente:** qué problema suele venir con eso.
3. **Qué hago:** una frase, con un resultado que la persona pueda respaldar.
4. **Pregunta pequeña:** fácil de contestar con sí o no. No pidas una reunión de una hora.

Largo: WhatsApp e Instagram hasta 60 palabras, LinkedIn hasta 80, correo hasta 110 más asunto.

Evita: "espero que estés muy bien", "vi tu perfil y me encantó", "soluciones integrales", halagos genéricos, adjuntos en el primer mensaje.

## Entrega

| Cliente | Dato usado (con enlace) | Mensaje | Confianza: alta, media o baja |

Después, un mensaje de seguimiento para quien no responda en cinco días hábiles, que aporte algo nuevo.

## Límites

- Usa información de la empresa o profesional, no de la vida privada.
- Si alguien pidió no ser contactado, queda fuera.
- Recomienda enviar de a pocos y a mano. Nada de envíos masivos por WhatsApp.
