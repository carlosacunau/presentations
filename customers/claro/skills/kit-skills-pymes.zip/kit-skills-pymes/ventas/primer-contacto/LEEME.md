# primer-contacto

Un mensaje distinto para cada cliente potencial, con una razón real para escribirle.

**Cómo pedirlo:** "Escribe el primer mensaje para estos clientes" y pegas tu lista.

**Ejemplo:** "Vendo uniformes para restaurantes. Escríbeles por WhatsApp a estos cinco locales" y pegas nombres y páginas web.

**Con búsqueda web activada** encuentra el dato de cada empresa por ti.
