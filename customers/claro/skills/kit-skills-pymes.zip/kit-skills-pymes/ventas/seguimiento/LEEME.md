# seguimiento

Te dice a quién escribirle hoy y te deja el mensaje redactado.

**Cómo pedirlo:** "¿A quién le hago seguimiento hoy?" y pegas tu lista, o "redacta el seguimiento para este cliente".

**Ejemplo:** "Le mandé una cotización de pintura a Marcela hace ocho días por $480.000, me preguntó si podía pagar en dos cuotas y no le contesté. Sí puede. Redacta el seguimiento."
