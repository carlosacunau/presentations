---
name: seguimiento
description: "Úsalo siempre que un cliente tenga una cotización o venta sin cerrar: redacta el seguimiento. Con 'le mandé una cotización', 'no me responde', 'no le contesté' o 'a quién le escribo hoy'."
---

# Seguimiento

Que ningún cliente se enfríe por falta de un mensaje a tiempo.

Quien te escribe es **quien vende**; el mensaje va de esa persona a su cliente. Cuidado al pasar lo que cuenta: si dice "me preguntó si podía pagar en cuotas, sí puedo", quien paga es el cliente y quien acepta es la persona ("sí, puedes pagar en dos cuotas").

## Dos usos

**Un cliente:** la persona cuenta qué pasó y recibe el mensaje.
**Toda la lista:** pega su planilla o sus notas y recibe a quién escribirle hoy, en qué orden y con qué texto.

## Lo que necesitas por cliente

Quién es, qué se le ofreció, último contacto (fecha y quién escribió), y si dejó una duda abierta. Con eso basta. Pide la fecha de hoy si no la sabes.

## Orden de la lista

1. Preguntaron algo y nadie les respondió.
2. Se les prometió algo con fecha y venció.
3. Tienen cotización que vence pronto.
4. Cotización sin respuesta hace más de cuatro días hábiles.
5. Conversaciones frías de más de un mes.

Los que dijeron que no, quedan fuera.

## El mensaje

- Empieza por algo específico de la última conversación, nunca por "¿pudiste ver mi mensaje?".
- **Aporta algo:** responde la duda que quedó, un dato útil, una opción distinta o una fecha que de verdad exista.
- Una sola pregunta al final. Entre 30 y 70 palabras en WhatsApp.
- Usa `mi-voz.md` si existe.

Hasta tres seguimientos: el primero retoma, el segundo aporta, el tercero cierra con amabilidad ("si ahora no es el momento, no hay problema, me avisas"). Después se deja en pausa.

## Entrega

| Orden | Cliente | Por qué hoy | Mensaje | Próxima fecha |

## Límites

Nunca inventes urgencia ("último cupo"), descuentos ni fechas. No ofrezcas visitas, llamadas, muestras ni condiciones que la persona no mencionó. No supongas por qué el cliente no respondió.
