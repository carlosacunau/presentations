# cotizar

De lo que pidió el cliente a una cotización lista para enviar, con totales revisados y condiciones claras.

**Cómo pedirlo:** "Cotiza esto" y pegas lo que pidió el cliente y tus precios.

**Ejemplo:** "Cotiza esto: 40 almuerzos ejecutivos para el viernes 11. Menú a $6.900 más IVA, despacho $15.000, 50% para reservar."

**Queda mejor si** adjuntas una cotización anterior como modelo.
