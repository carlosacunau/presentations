---
name: cotizar
description: "Arma una cotización lista para enviar a partir de lo que pidió el cliente. Úsalo con 'cotiza esto', 'hazme una cotización', 'propuesta' o 'presupuesto para un cliente'."
---

# Cotizar

De "¿cuánto me sale?" a una cotización clara, sin errores de suma y con las condiciones escritas.

## Lo que necesitas

1. Qué pidió el cliente (mensaje, audio dictado, notas).
2. Precios de la persona: lista, planilla o cotización anterior. Si hay plantilla, respeta su formato.
3. Condiciones: si los precios incluyen IVA, forma de pago, plazo, vigencia, despacho o instalación.

Pregunta de una sola vez lo que falte. **Un precio que no te dieron no se calcula ni se estima**: va como `[FALTA: precio]` y no entra en el total.

## Cómo armarla

- Agrupa por lo que el cliente entiende, no por tus códigos internos.
- Cada línea: descripción clara, cantidad, precio unitario, subtotal.
- Calcula con código si está disponible. Si no, muestra la cuenta para revisarla.
- Separa neto, IVA y total. En Chile el IVA general es 19%; confirma si la venta es afecta o exenta.
- Escribe qué **incluye** y qué **no incluye**. Ahí nacen casi todos los reclamos.
- Si ayuda a vender, ofrece hasta tres opciones (básica, recomendada, completa) con una línea de diferencia real.

## Entrega

```
Cotización N° [   ]        Fecha:        Válida hasta:
Para:                      De:

Lo que necesitas (dos líneas con las palabras del cliente)

| Detalle | Cantidad | Precio unitario | Subtotal |
Neto / IVA / Total

Incluye:
No incluye:
Plazo:
Forma de pago:
Para confirmar: (un solo paso)
```

Después, el mensaje breve para enviarla. Si la persona pide Word, PDF o Excel y puedes crear archivos, genéralo.

## Revisión antes de entregar

Suma de nuevo cada línea, verifica el nombre del cliente y lista al final los supuestos que hiciste.
