---
name: calcular-precio
description: "Úsala siempre que haya costos y precios: calcula costo real, margen y precio. Con 'cuánto cobro', 'estoy cobrando bien', 'vendo a tanto y me cuesta tanto' o 'me piden descuento'."
---

# Calcular precio

Responde tres preguntas: cuánto cuesta de verdad, cuánto queda y qué precio conviene.

## Paso 1. Reúne los números

Pregunta por bloques, no todo de golpe:
- **Costos directos** por unidad o servicio: materiales, insumos, empaque, despacho, comisiones (tarjeta, plataforma).
- **Tiempo:** horas por unidad o trabajo y cuánto cuesta esa hora (incluida la hora de la persona dueña, que casi siempre se olvida).
- **Costos fijos del mes:** arriendo, sueldos, servicios, software, contador.
- **Volumen:** cuántos vende en un mes normal.
- **Precio actual** y si incluye IVA.
- **Mercado:** qué cobran otros, si lo sabe.

Lo que no sepa va como supuesto visible. Nunca uses un supuesto en silencio.

## Paso 2. Calcula (con código si está disponible)

Trabaja siempre **sin IVA**: si el precio lo incluye, en Chile divide por 1,19.

- Costo variable = directos + tiempo
- Fijo por unidad = costos fijos / volumen. Si vende varios productos, pregunta qué parte de los fijos corresponde a este.
- Costo total = variable + fijo por unidad
- Margen de contribución = precio neto menos costo variable
- Ganancia = precio neto menos costo total
- Margen % = ganancia / precio neto
- Punto de equilibrio = costos fijos / margen de contribución
- Precio para un margen deseado = costo total / (1 menos margen)

Aclara si hace falta: margen no es lo mismo que recargo. Costo 100 y precio 150 es 50% de recargo y 33% de margen.

Cuidado con contar el tiempo dos veces: si un sueldo ya está en los costos fijos, no lo sumes otra vez como costo de hora.

## Paso 3. Entrega

1. La respuesta en dos líneas: hoy ganas o pierdes tanto por unidad.
2. Tabla con el cálculo.
3. Tres precios: mínimo (no bajar de aquí), recomendado y alto, con la razón de cada uno.
4. Qué pasa si vendes 20% menos o si el costo principal sube 10%.
5. Supuestos por confirmar.

## Si le piden descuento

Calcula cuántas ventas más necesita para ganar lo mismo. Sugiere cambiar el alcance (menos cantidad, otro plazo, pago por adelantado) antes que bajar el precio.

## Límites

Los impuestos los confirma su contador. El precio lo decide la persona: muestra los números y tu recomendación por separado.
