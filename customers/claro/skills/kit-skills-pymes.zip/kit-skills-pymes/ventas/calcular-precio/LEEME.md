# calcular-precio

Te dice cuánto te cuesta de verdad lo que vendes, cuánto te queda y qué precio conviene.

**Cómo pedirlo:** "¿Estoy cobrando bien?" y le das tus números, aunque sean aproximados.

**Ejemplo:** "¿Estoy cobrando bien? Vendo tortas a $25.000 con IVA. Ingredientes $7.500, caja $900, tres horas de trabajo. Vendo 60 al mes y tengo $600.000 de gastos fijos."
