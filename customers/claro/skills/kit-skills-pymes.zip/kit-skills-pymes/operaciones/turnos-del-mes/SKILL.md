---
name: turnos-del-mes
description: "Arma los turnos del mes del equipo y revisa que cuadren. Úsala con 'arma los turnos', 'horario del equipo', 'quién trabaja' o 'cambio de turno'."
---

# Turnos del mes

Los turnos del mes, repartidos con justicia y revisados regla por regla.

## Lo que necesitas

Pregunta en un solo mensaje lo que falte:
1. Mes, y días y horas de atención. Feriados y si abren.
2. Cuántas personas por tramo, y qué rol se necesita siempre (caja, encargado).
3. Equipo: nombre o inicial, rol, horas semanales de contrato.
4. Restricciones: vacaciones, permisos, estudios, quién no puede abrir o cerrar.
5. Reglas del negocio: descanso entre turnos, domingos libres, quiénes no coinciden.
6. Último domingo o feriado trabajado por cada uno.

No pidas motivos personales ni médicos: basta "no disponible".

## Reglas legales

La jornada máxima, los descansos, las horas extra y los domingos libres dependen del contrato y de la ley vigente. **Pide a la persona los límites que usa** y, si no los sabe, que los confirme con su contador o en la Dirección del Trabajo. No afirmes que el turno cumple la ley.

## Cómo armarlo

1. Primero lo que no se mueve: ausencias, roles obligatorios, límites.
2. Después los tramos difíciles: cierres, fines de semana, feriados.
3. Luego el resto, parejo en horas y en turnos pesados.

Usa código si está disponible. **Si no hay solución, dilo:** qué día falta gente, cuánta, y dos o tres salidas posibles. No rompas una regla en silencio.

## Entrega

1. Calendario por semana: días en columnas, personas en filas. Excel si puedes.
2. Resumen por persona: horas por semana y del mes, domingos, cierres.
3. Control, regla por regla: se cumple o no se cumple, y dónde.
4. Mensaje breve para el grupo del equipo.

## Cambios

Si alguien falta o pide cambio, mueve lo mínimo, muestra antes y después, y repite el control.
