# turnos-del-mes

Los turnos del mes, parejos y revisados, con el mensaje listo para el equipo.

**Cómo pedirlo:** "Arma los turnos de diciembre".

**Ejemplo:** "Arma los turnos de diciembre. Cafetería, lunes a sábado de 8 a 20, dos personas siempre y tres los sábados. Somos cinco; Javi no puede los martes y Ana sale de vacaciones del 14 al 20."
