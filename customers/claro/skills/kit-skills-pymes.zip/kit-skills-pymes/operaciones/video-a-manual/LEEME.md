# video-a-manual

Grabas cómo se hace una tarea y queda el manual para la próxima persona que contrates.

**Cómo pedirlo:** "Haz el manual de este video".

**Ejemplo:** "Haz el manual de cierre-de-caja.mp4, es para la persona que entra el lunes."

**Dónde funciona:** con el video, en **Claude Code** (necesita FFmpeg, gratis; Claude te ayuda a instalarlo). En el chat normal funciona con capturas de pantalla en orden.

**Cuidado:** graba con datos de prueba, sin claves ni datos de clientes.
