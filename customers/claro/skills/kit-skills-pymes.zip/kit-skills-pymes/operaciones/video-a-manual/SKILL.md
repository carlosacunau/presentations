---
name: video-a-manual
description: "Convierte una grabación de pantalla o video de un proceso en un manual paso a paso. Úsala con 'haz el manual de este video', 'documenta este proceso' o 'instructivo'."
---

# De video a manual

Alguien graba cómo hace una tarea y queda el manual para la próxima persona. Al explicar en voz alta, la gente se salta la mitad de lo que hace: el manual sigue **lo que se ve**, no solo lo que se dice.

## Dos caminos

**En Claude Code, con el archivo de video en la carpeta** (necesita FFmpeg instalado; compruébalo con `ffmpeg -version` y, si falta, ofrece instalarlo):
1. Mira cuánto dura: `ffprobe -v error -show_entries format=duration -of csv=p=0 "video.mp4"`
2. Saca una imagen cada dos segundos en una carpeta nueva: `mkdir cuadros && ffmpeg -i "video.mp4" -vf "fps=1/2,scale=1280:-2" cuadros/%05d.jpg`. Si dura más de 20 minutos, trabaja por tramos.
3. Míralas en orden y anota cada cambio de pantalla, clic, campo y dato. Si algo pasó entre dos imágenes, saca más de ese tramo: `ffmpeg -ss 00:01:20 -t 10 -i "video.mp4" -vf fps=4 cuadros/detalle_%03d.jpg`
4. Si la persona tiene la transcripción del audio, úsala para entender el porqué.
5. Al terminar, pregunta si borras la carpeta de cuadros.

**En el chat, sin el video:** pide capturas en orden, una por paso, y que cuente qué hace en cada una. Si sube un video que no puedes ver, dilo; no inventes los pasos.

Antes de empezar, avisa: si en la pantalla hay claves o datos de clientes, conviene grabar de nuevo con datos de prueba. Nunca copies una clave al manual.

## El manual

```
# Cómo [tarea]
Para qué sirve · Quién lo hace · Cada cuánto · Cuánto toma
## Antes de empezar (accesos, archivos, datos)
## Pasos
1. [Acción] en [pantalla], [botón o campo exacto]. Debes ver: [resultado]. (minuto 0:42)
## Decisiones (si pasa esto, haz esto)
## Errores comunes
## Cómo saber que quedó bien
## Se vio en pantalla, pero no se explicó
## Preguntas para quien grabó
```

- Un paso, una acción. Textos de botones tal como aparecen.
- Lo que no se distingue va como `[CONFIRMAR]`.
- Si lo dicho y lo mostrado no coinciden, vale lo mostrado y lo anotas.

## Cierre

Entrega además una versión de diez líneas para pegar en la pared, y pide: "Que otra persona lo siga sin ayuda. ¿Dónde se trabó?". Corrige con eso.
