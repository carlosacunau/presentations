---
name: nota-de-voz-a-tareas
description: "Convierte una nota de voz o un dictado desordenado en una lista de tareas con prioridad. Úsala con 'ordena esto', 'nota de voz', 'se me ocurrieron varias cosas' o un dictado."
---

# De nota de voz a tareas

La persona habla dos minutos sin orden y sale con una lista que puede hacer hoy.

## Entrada

Lo más simple es dictar con el micrófono del teclado o de la app de Claude. También sirve una transcripción pegada. Si adjunta un audio que no puedes escuchar, dilo y pide que lo dicte o pegue el texto.

Espera errores de dictado: nombres mal escritos, palabras cambiadas, frases cortadas. Si un nombre, monto o fecha suena dudoso, va a "Por confirmar"; no lo corrijas en silencio.

## Cómo procesar

1. **Saca todo primero.** Cada cosa mencionada, aunque sea de pasada. No filtres todavía.
2. **Clasifica:** tarea, recordatorio con fecha, idea, decisión pendiente, desahogo. El desahogo no se convierte en tarea.
3. **Une repetidos.** Si se contradice, quédate con lo último que dijo y avísalo.
4. **Vuelve accionable:** verbo más resultado. "Lo del proveedor" pasa a "Llamar al proveedor para confirmar la entrega del jueves", solo si eso fue lo que dijo.
5. **Prioriza:** qué vence antes, qué le cuesta plata o clientes si no se hace, qué frena a otros.

## Entrega

```
## Hoy (máximo 3)
## Esta semana
## Delegar (a quién, si lo dijo)
## Ideas para después
## Decisiones pendientes
## Por confirmar
```

Cada tarea en una línea con fecha si la dijo. Al final: "Saqué N cosas de tu nota" para que note si falta algo. Ofrece redactar el mensaje de lo que se delega.

## Límites

No agregues tareas que no dijo ni supongas para qué sirve algo: si "las cajas" puede ser más de una cosa, va a "Por confirmar". Cada cosa aparece en una sola sección. Si tienes una sugerencia, una sola, marcada como tuya.
