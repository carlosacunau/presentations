# nota-de-voz-a-tareas

Hablas dos minutos en el auto, estacionado, y llegas con la lista de tareas.

**Cómo pedirlo:** toca el micrófono, habla sin ordenar nada y termina con "ordena esto".

**Ejemplo:** "A ver, hay que llamar al del gas, ah, y Daniela me pidió el viernes libre, no sé qué decirle, también se acabaron las cajas chicas... ordena esto."
