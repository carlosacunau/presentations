---
name: ordenar-planilla
description: "Limpia una planilla desordenada y saca conclusiones útiles. Úsalo cuando adjunte un Excel o CSV y diga 'ordena esta planilla', 'limpia estos datos' o 'qué me dice esto'."
---

# Ordenar una planilla

Una planilla desordenada entra; sale limpia, con un registro de los cambios y conclusiones que se pueden comprobar.

## Paso 1. Mira sin tocar

Di en pocas líneas: hojas, filas, columnas, qué parece ser cada una y qué problemas hay (fechas mezcladas, montos como texto, nombres repetidos con distinta escritura, filas vacías, totales en medio, celdas combinadas). Pregunta **una cosa:** "¿Qué quieres decidir con esta planilla?".

## Paso 2. Limpia en una copia

El original nunca se modifica. Usa código si está disponible.

- Una fila por registro y un solo encabezado.
- Fechas en un formato. Si 03/04 puede ser marzo o abril, pregunta.
- Montos como número. En Chile el punto separa miles: "1.500" suele ser mil quinientos. Verifícalo con el resto de la columna.
- Nombres: une solo los que son obviamente iguales (mayúsculas, tildes, espacios). Los parecidos van a "¿son el mismo?" y decide la persona.
- Vacíos: quedan vacíos. No los rellenes con promedios ni ceros.
- Duplicados: se marcan; no se borran sin aprobación.

## Paso 3. Conclusiones

De tres a cinco, conectadas con la decisión que quiere tomar. Cada una con el número, cómo se calculó y cuántas filas la respaldan. Si hay pocos datos, dilo. Que dos cosas pasen juntas no prueba que una cause la otra.

## Entrega

1. Archivo limpio (Excel), con hojas: Datos limpios, Cambios, Por revisar.
2. Control: filas originales = limpias + apartadas, y la suma de la columna principal antes y después.
3. Conclusiones y una recomendación.
4. Un consejo para que la planilla no se vuelva a desordenar.

Si los controles no cuadran, dilo antes que cualquier conclusión. Si hay datos personales que no se necesitan para el análisis, sugiere quitarlos antes de subir el archivo.
