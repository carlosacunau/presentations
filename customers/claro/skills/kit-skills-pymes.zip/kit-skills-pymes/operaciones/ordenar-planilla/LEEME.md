# ordenar-planilla

Tu planilla desordenada, limpia, con los cambios anotados y conclusiones que puedes comprobar. El original no se toca.

**Cómo pedirlo:** adjunta el Excel y escribe "ordena esta planilla".

**Ejemplo:** "Ordena esta planilla de ventas. Quiero saber qué productos debería dejar de vender."
