# Kit de skills para pymes

32 tareas que ya no vas a hacer a mano. Ocho carpetas, una por área del negocio, con cuatro skills cada una.

Un **skill** es una receta: una carpeta con un archivo `SKILL.md` que le enseña a tu asistente de IA a hacer un trabajo siempre de la misma manera. Funcionan en Claude, ChatGPT, Codex y Gemini.

**Abre `DESCRIPCION DE SKILLS.html`** (doble clic, se abre en tu navegador). Ahí ves qué hace cada skill, cómo pedirlo y cómo instalarlo.

## Cómo instalar un skill en Claude (chat)

1. Descarga el kit completo y descomprímelo.
2. En Claude, entra a **Configuración > Capacidades** y activa la creación de archivos y ejecución de código.
3. Entra a **Personalizar > Skills**, toca **+** y **Crear skill**, y elige la opción para subirlo.
4. Sube el ZIP del skill que elegiste. Están en la carpeta `para-subir`, uno por skill. Esos no hay que descomprimirlos.
5. Abre un chat nuevo y pídelo con tus palabras. Cada `LEEME.md` trae un ejemplo.

Si Claude responde sin usar el skill, pídelo por su nombre: "usa el skill cotizar".

Los nombres de los menús pueden cambiar. Hazlo desde el computador.

## Cómo instalarlos con un agente (Claude Code, Codex, Gemini, ChatGPT)

Descarga el kit completo y descomprímelo. Puede quedar en Descargas, no hay que moverlo.

Después abre tu agente y dile dónde está el kit y cuáles quieres. El agente se encarga del resto. Por ejemplo:

- "En Descargas está la carpeta kit-skills-pymes. Instálame cotizar, seguimiento y mi-voz."
- "En Descargas está la carpeta kit-skills-pymes. Muéstrame la lista de skills para elegir."

## Lo que hay adentro

| Carpeta | Skills |
|---|---|
| clientes | responder-mensajes, responder-resenas, reunion-a-tareas, datos-personales |
| ventas | primer-contacto, cotizar, seguimiento, calcular-precio |
| finanzas | registrar-movimientos, gastos-desde-fotos, quien-me-pago, recordar-cobro |
| marketing | publicar-desde-foto, semana-de-publicaciones, mirar-competencia, que-dice-la-gente |
| operaciones | nota-de-voz-a-tareas, ordenar-planilla, video-a-manual, turnos-del-mes |
| documentos | resumir-documento, revisar-contrato, aprender-de-un-video, armar-presentacion |
| decisiones | pensar-una-decision, revisar-herramienta, explicar-simple, postular-a-fondos |
| mi-espacio | conoce-mi-negocio, mi-voz, preparar-reunion, arreglar-error |

- **Con búsqueda web activada:** mirar-competencia, que-dice-la-gente, revisar-herramienta. También ayuda en primer-contacto, postular-a-fondos y preparar-reunion.
- **Mejor en Claude Code:** video-a-manual (con el archivo de video) y aprender-de-un-video (con el enlace). En el chat funcionan con capturas o con la transcripción pegada.

## Tres cuidados

1. **Tú revisas y tú envías.** La IA se puede equivocar: comprueba montos, fechas y nombres.
2. **Nunca compartas claves ni códigos.** Tapa RUT, cuentas y datos de clientes que no hagan falta.
3. **No reemplaza** a tu contador ni a tu abogado.

Hecho por Fiba Labs. fibalabs.com
