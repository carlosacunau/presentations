# Kit de skills para pymes: instrucciones para el agente

Esta carpeta es un kit de 32 skills en formato `SKILL.md` (sirven en Claude, ChatGPT, Codex y Gemini): ocho carpetas, una por área del negocio, con cuatro skills cada una. Quien la abrió probablemente tiene un negocio y no programa. Háblale simple, de tú y en español.

## En tu primera respuesta

Antes de cualquier otra cosa:

1. Cuéntale en una o dos líneas qué es este kit.
2. Ofrécele abrir `DESCRIPCION DE SKILLS.html` en su navegador, donde ve qué hace cada skill y cómo pedirlo. Si acepta, ábrelo con el comando de su sistema:
   - Mac: `open "DESCRIPCION DE SKILLS.html"`
   - Windows: `start "" "DESCRIPCION DE SKILLS.html"`
   - Linux: `xdg-open "DESCRIPCION DE SKILLS.html"`
3. Ofrécele instalar los skills que quiera.

Si su primer mensaje ya pide algo concreto, hazlo y ofrece la descripción al final, en una línea.

## Para instalar skills

Sirve para Claude Code, Codex, Gemini o cualquier agente que lea skills. La persona no tiene que mover archivos ni buscar carpetas: eso lo haces tú.

1. Pregunta cuáles quiere, si no lo dijo. La decisión es suya: no le recomiendes cuáles instalar. Si no sabe, muéstrale la lista con una línea por skill o ofrécele abrir la descripción.
2. Copia cada skill elegido (por ejemplo, la carpeta `ventas/cotizar`) a la carpeta donde tu herramienta carga skills para todas sus sesiones. Créala si no existe. Si la persona pide instalarlos solo en la carpeta de su negocio, ponlos ahí.
3. Al terminar, dile qué instalaste, si tiene que abrir una sesión nueva para usarlos y el ejemplo de cómo pedir cada uno. El ejemplo está en el `LEEME.md` de cada skill.

## Para el chat de Claude (claude.ai)

Los skills se suben uno por uno desde el navegador. Los ZIP listos para subir están en `para-subir/`, uno por skill, y los pasos están en `LEEME.md`. Explícale los pasos; tú no puedes subirlos en su lugar.

## Cuidados

- No modifiques los archivos del kit.
- No copies ni instales nada que la persona no haya pedido.
