# Kit de skills para pymes: instrucciones para el agente

Esta carpeta es un kit de 32 skills para Claude: ocho carpetas, una por área del negocio, con cuatro skills cada una. Quien la abrió probablemente tiene un negocio y no programa. Háblale simple, de tú y en español.

## En tu primera respuesta

Antes de cualquier otra cosa:

1. Cuéntale en una o dos líneas qué es este kit.
2. Ofrécele abrir `DESCRIPCION DE SKILLS.html` en su navegador, donde ve qué hace cada skill y cómo pedirla. Si acepta, ábrelo con el comando de su sistema:
   - Mac: `open "DESCRIPCION DE SKILLS.html"`
   - Windows: `start "" "DESCRIPCION DE SKILLS.html"`
   - Linux: `xdg-open "DESCRIPCION DE SKILLS.html"`
3. Ofrécele instalar las skills que quiera.

Si su primer mensaje ya pide algo concreto, hazlo y ofrece la descripción al final, en una línea.

## Para instalar skills en Claude Code

1. Pregunta cuáles quiere. La decisión es suya: no le recomiendes cuáles instalar. Si no sabe, ofrécele abrir la descripción para elegir.
2. Pregunta en qué carpeta trabaja con su negocio. Copia cada skill elegida (por ejemplo, la carpeta `ventas/cotizar`) dentro de `.claude/skills/` en esa carpeta. Si `.claude/skills/` no existe, créala.
3. Al terminar, dile que abra una sesión nueva de Claude Code en esa carpeta para que las skills se carguen, y dale el ejemplo de cómo pedir cada una. El ejemplo está en el `LEEME.md` de cada skill.

## Para el chat de Claude (claude.ai)

Las skills se suben una por una desde el navegador. Los ZIP listos para subir están en `para-subir/`, uno por skill, y los pasos están en `LEEME.md`. Explícale los pasos; tú no puedes subirlas en su lugar.

## Cuidados

- No modifiques los archivos del kit.
- No copies ni instales nada que la persona no haya pedido.
