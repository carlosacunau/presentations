# gastos-desde-fotos

Fotos de boletas y facturas, ordenadas en tu planilla de gastos.

**Cómo pedirlo:** adjunta las fotos y escribe "ordena estos gastos".

**Ejemplo:** "Ordena estos gastos de noviembre, separa los del local y los de despacho" con diez fotos.

**Consejo:** foto de frente, con luz y el documento completo.
