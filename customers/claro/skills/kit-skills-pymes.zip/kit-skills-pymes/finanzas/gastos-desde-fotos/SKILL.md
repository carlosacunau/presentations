---
name: gastos-desde-fotos
description: "Pasa fotos de boletas y facturas a una planilla de gastos. Úsala con fotos de boletas, 'ordena mis gastos', 'rendición de gastos' o 'pasa estas facturas a Excel'."
---

# Gastos desde fotos

Fotos de boletas y facturas a una planilla de gastos ordenada.

## Paso 1. Lee cada documento

Un documento por fila, aunque una foto traiga varios. Extrae: tipo (boleta, factura, boleta de honorarios, comprobante de pago, otro), número, fecha, proveedor, RUT del proveedor si se ve, neto, IVA, total, medio de pago y qué se compró en pocas palabras.

- Lo que no se lee va como `[REVISAR]`. Nunca completes un número por lógica.
- Si hay neto, IVA y total, comprueba que sumen. Si no suman, márcalo.
- Un comprobante de tarjeta no es una boleta: anótalo como "comprobante, falta documento".
- Si una foto está cortada o borrosa, pide esa foto de nuevo y sigue con las demás.

## Paso 2. Ordena

- Categoría según su planilla, o: Insumos, Mercadería, Servicios, Arriendo, Transporte, Alimentación, Marketing, Software, Equipamiento, Otros.
- Duplicados: mismo proveedor, número y total. Señálalos, no los borres.
- Gastos que parecen personales: pregunta, no juzgues.

## Entrega

| N° | Fecha | Tipo | Número | Proveedor | RUT | Detalle | Neto | IVA | Total | Categoría | Estado |

Estado: OK, REVISAR o FALTA DOCUMENTO. Después: total por categoría, total general, cuántos quedaron por revisar y la lista exacta de lo que falta. Si puedes crear archivos, entrega el Excel.

Comprueba que el número de filas coincida con el número de documentos recibidos y dilo: "12 fotos, 14 documentos, 14 filas".

## Límites

Qué gasto da derecho a crédito de IVA o se puede descontar lo define su contador. Recuérdale guardar los originales.
