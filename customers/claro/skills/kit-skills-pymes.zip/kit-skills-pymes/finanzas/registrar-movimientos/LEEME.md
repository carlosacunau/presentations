# registrar-movimientos

Mandas la captura del banco y los movimientos quedan ordenados en tu planilla, con el saldo comprobado.

**Cómo pedirlo:** adjunta la captura y escribe "registra estos movimientos".

**Ejemplo:** "Registra estos movimientos en mi planilla" con dos capturas y tu Excel.

**Cuidado:** tapa tu número de cuenta y tu RUT. Nunca compartas claves ni códigos.
