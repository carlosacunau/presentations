---
name: registrar-movimientos
description: "Pasa capturas del banco a una planilla ordenada de ingresos y gastos. Úsalo con una captura de movimientos, 'registra esto', 'pásalo a mi planilla' o 'ordena mi cartola'."
---

# Registrar movimientos

La persona manda una captura o la cartola del banco y los movimientos quedan en su planilla, con las sumas revisadas.

## Antes

- Sugiere tapar números de cuenta y RUT: no hacen falta.
- **Nunca pidas claves, códigos ni acceso al banco.** Si aparecen en la imagen, dilo y no los repitas.
- Si ya tiene planilla, pídela y respeta sus columnas y categorías. Si no, usa la de abajo.

## Paso 1. Transcribe

Fila por fila, en el orden en que aparecen: fecha, descripción tal cual, cargo o abono, saldo si se ve. Si un dígito no se lee bien, pon `[REVISAR]` y pregunta. No adivines montos. Si la fecha no trae año, pregúntalo.

## Paso 2. Revisa

- **Saldo:** si la imagen muestra saldos, comprueba que saldo anterior más abonos menos cargos dé el siguiente. Si no cuadra, di entre qué filas.
- **Duplicados:** dos capturas seguidas suelen repetir filas. Compara fecha, monto, descripción y saldo. Dos compras iguales el mismo día pueden ser reales: pregunta, no borres.
- **Traspasos entre cuentas propias:** no son ingreso ni gasto. Márcalos aparte.

## Paso 3. Clasifica

Categorías base: Ventas, Otros ingresos, Proveedores, Sueldos, Arriendo y servicios, Impuestos, Comisiones bancarias, Transporte, Marketing, Software, Retiros de la persona dueña, Traspaso propio, Por clasificar. Si dudas, "Por clasificar". Aprende de sus correcciones dentro de la misma conversación.

## Entrega

| Fecha | Descripción | Ingreso | Gasto | Categoría | Nota |

Más un resumen: total de ingresos, total de gastos, diferencia, filas por revisar y si el saldo cuadró o no se pudo comprobar. Si puedes crear archivos, entrega el Excel; si ya tenía uno, agrega filas sin tocar las anteriores.

## Límites

No es contabilidad ni declaración de impuestos. Que un abono sea una venta lo confirma la persona.
