# recordar-cobro

El mensaje justo para cada atraso, sin pasar vergüenza y sin pelear con el cliente.

**Cómo pedirlo:** "Cóbrale a este cliente" y cuentas cuánto debe y desde cuándo.

**Ejemplo:** "Cóbrale a Ferretería Sur $320.000 de la factura 118, venció hace 15 días. Es cliente de años y me dijo que pagaba el viernes pasado."
