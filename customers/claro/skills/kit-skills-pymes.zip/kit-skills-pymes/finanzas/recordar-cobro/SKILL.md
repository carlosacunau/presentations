---
name: recordar-cobro
description: "Redacta mensajes de cobro amables y firmes según el atraso. Úsalo con 'cóbrale', 'me deben', 'factura vencida', 'recordatorio de pago' o 'no me paga'."
---

# Recordar cobro

Cobrar sin pasar vergüenza y sin dañar la relación: el mensaje justo para cada atraso.

## Lo que necesitas

Quién debe, monto, documento o concepto, fecha de vencimiento, qué se conversó antes, canal y cómo es la relación. Pide la fecha de hoy si no la sabes y calcula los días de atraso.

Antes de redactar, confirma: "¿Revisaste que no haya pagado?". Cobrar algo ya pagado es el peor error.

## El tono según el atraso

| Momento | Tono | Qué dice |
|---|---|---|
| 3 días antes | Servicial | Aviso con monto, fecha y datos de pago |
| 1 a 7 días | Liviano | Puede haberse pasado; ¿lo revisas? |
| 8 a 20 días | Directo | Pide una fecha concreta |
| 21 a 45 días | Firme | Recuento con fechas, ofrece plan de pago, pide respuesta con fecha |
| Más de 45 días | Formal | Por correo, con recuento y siguiente paso real |

Ajusta si es un cliente de años o si ya rompió una promesa de pago.

## Cada mensaje lleva

Monto exacto, documento, fecha de vencimiento, cómo pagar `[FALTA: datos de pago]` y una sola pregunta: "¿Qué día lo puedes transferir?". De 30 a 80 palabras en WhatsApp.

## Nunca

- Amenazar, humillar, mentir sobre consecuencias o anunciar acciones legales que la persona no vaya a tomar.
- Contarle la deuda a terceros ni escribir en grupos.
- Escribir de noche o en domingo. Si el deudor es un consumidor, hay reglas legales sobre la cobranza: recomienda confirmarlas.
- Inventar intereses o multas que no estén pactados.

## Entrega

El mensaje de hoy y la secuencia siguiente con fechas. Si son varios deudores, una tabla ordenada por monto y atraso. Si hay disputa sobre lo entregado, no redactes cobro: redacta un mensaje para resolver la diferencia. En deudas grandes o muy antiguas, sugiere hablar con un abogado.
