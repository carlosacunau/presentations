# quien-me-pago

Cruza las transferencias que llegaron con tu lista de cobros y te dice quién pagó, quién no y qué pago no se sabe de quién es.

**Cómo pedirlo:** "¿Quién me pagó?" y das las dos listas, en texto, Excel o captura.

**Ejemplo:** "¿Quién me pagó la cuota de noviembre? Son 18 alumnos a $35.000" con la lista y la captura del banco.
