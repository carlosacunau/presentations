---
name: quien-me-pago
description: "Cruza las transferencias recibidas con la lista de quién debe y dice quién pagó y quién no. Úsala con 'quién me pagó', 'cruza estos pagos' o 'quién me debe'."
---

# Quién me pagó

Cruza dos listas: lo que se esperaba cobrar y lo que llegó al banco.

## Lo que necesitas

1. **Quién debe:** nombre, monto, concepto y, si hay, RUT o fecha.
2. **Qué llegó:** captura, cartola o lista de transferencias.

Pregunta antes de cruzar: ¿puede pagar otra persona por el cliente (pareja, empresa)? ¿Se aceptan pagos parciales?

## Cómo cruzar

| Nivel | Cuándo | Qué haces |
|---|---|---|
| Seguro | Nombre o RUT y monto coinciden | Marcas pagado |
| Probable | Coincide el monto y parte del nombre, o el nombre y un monto distinto | Pides confirmación |
| Sin pareja | Nada calza | Va a "pagos sin identificar" |

- Nunca marques pagado solo porque coincide el monto.
- Ojo con apellidos iguales, nombres de empresa distintos del nombre del local, y un pago que cubre varias deudas.
- Una transferencia se usa una sola vez. Si dos deudas podrían calzar con ella, pregunta.
- Si el monto es distinto: anota pagado, saldo pendiente o exceso.
- Dos transferencias idénticas pueden ser un pago doble o dos pagos. Pregunta.

## Entrega

| Cliente | Debía | Pagó | Fecha | Estado | Cómo se identificó |

Estados: PAGADO, PARCIAL, POR CONFIRMAR (hay una transferencia probable), PENDIENTE (no hay ninguna). Después:
- Pagos sin identificar.
- Preguntas para confirmar, numeradas.
- Control: total recibido = asignado (solo lo seguro, completo o parcial) + por confirmar + sin identificar. Muestra los cuatro números. Si no cuadra, no entregues como terminado; di cuánto falta.

Cuando la persona confirme, actualiza la tabla completa. Ofrece redactar recordatorios para los pendientes.

## Límites

Sugiere tapar números de cuenta. No contactes a nadie.
