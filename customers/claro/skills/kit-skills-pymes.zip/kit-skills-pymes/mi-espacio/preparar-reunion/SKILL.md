---
name: preparar-reunion
description: "Úsalo antes de una reunión con un cliente, proveedor, banco o socio: una página con qué saber, qué preguntar y qué responder. Con 'tengo reunión con', 'prepárame la reunión' o 'mañana veo a'."
---

# Preparar una reunión

Llegar sabiendo qué quieres sacar de la reunión, qué te van a preguntar y qué vas a responder.

## Lo que necesitas

1. **Con quién es:** nombre, empresa, cargo si lo sabe, y qué relación tienen (cliente nuevo, cliente de siempre, proveedor, banco, posible socio).
2. **Para qué es,** en palabras de la persona.
3. **Lo que ya pasó:** correos, mensajes, cotizaciones o notas anteriores. Si los tiene, pide que los pegue.
4. Cuánto dura y si es presencial o en línea.

El objetivo es lo único indispensable: si falta, pregúntalo antes de seguir. Para lo demás, como máximo dos preguntas juntas.

## Investiga

Si tienes búsqueda web, busca la empresa y a la persona: a qué se dedican, noticias recientes, tamaño, qué publican. Usa solo lo que puedas enlazar y marca lo que no es seguro. Si no tienes búsqueda web, trabaja con lo que te dio la persona y díselo.

## Entrega, una página

1. **Objetivo:** qué tiene que salir de la reunión, en una frase, y el mínimo aceptable.
2. **Lo que conviene saber** de la otra parte: de tres a cinco puntos, con enlace cuando viene de internet.
3. **Preguntas para hacer:** de tres a cinco, abiertas y en orden.
4. **Lo que te pueden preguntar o pedir:** las tres cosas más probables, con una respuesta corta para cada una basada en lo que la persona contó. Si aplica, incluye precio, plazo o descuento.
5. **Qué llevar:** documentos, números, muestras.
6. **Cómo cerrar:** el siguiente paso concreto que vas a proponer, con fecha.

Si es con el banco o por un crédito, agrega los papeles que suelen pedir y recomienda confirmarlos con el ejecutivo.

## Después

Ofrece armar el resumen y el seguimiento cuando la persona cuente cómo le fue.

## Límites

- No inventes datos de la otra empresa ni de la persona. Si no lo encontraste, dilo.
- No sugieras presionar, mentir ni prometer lo que la persona no puede cumplir.
- Si el tema es legal, laboral o tributario y delicado, sugiere llevar al abogado o al contador.
