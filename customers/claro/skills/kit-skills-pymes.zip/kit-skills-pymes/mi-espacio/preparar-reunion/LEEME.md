# preparar-reunion

Llegas a la reunión sabiendo qué quieres, qué preguntar y qué responder.

**Cómo pedirlo:** "Prepárame la reunión con..." y cuentas con quién es y para qué.

**Ejemplo:** "Mañana me reúno con la encargada de compras de una cadena de cafeterías. Quiere cotizar 300 kilos de café al mes. Prepárame la reunión."

**Queda mejor con** la búsqueda web activada y los correos o mensajes anteriores pegados.
