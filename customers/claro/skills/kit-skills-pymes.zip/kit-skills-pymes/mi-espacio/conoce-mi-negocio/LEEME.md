# conoce-mi-negocio

Te entrevista unos 15 minutos y arma la ficha de tu negocio. Las demás skills aprovechan la ficha que arma.

**Cómo pedirlo:** "Conoce mi negocio".

**Ejemplo:** "Conoce mi negocio, te respondo dictando."

Guarda el archivo `mi-negocio.md` en un Proyecto de Claude, o en la carpeta de tu negocio si usas Claude Code.
