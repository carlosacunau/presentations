# conoce-mi-negocio

Te entrevista unos 15 minutos y arma la ficha de tu negocio. **Empieza por esta:** las demás funcionan mejor con ella.

**Cómo pedirlo:** "Conoce mi negocio".

**Ejemplo:** "Conoce mi negocio, te respondo dictando."

Guarda el archivo `mi-negocio.md` en un Proyecto de Claude, o en la carpeta de tu negocio si usas Claude Code.
