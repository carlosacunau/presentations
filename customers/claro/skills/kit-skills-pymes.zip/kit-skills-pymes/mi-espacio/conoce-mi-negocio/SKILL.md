---
name: conoce-mi-negocio
description: "Entrevista a la persona y arma mi-negocio.md, la ficha que Claude usa en todo lo demás. Úsala con 'conoce mi negocio', 'entrevístame' o 'arma el perfil de mi empresa'."
---

# Conoce mi negocio

Una entrevista de unos 15 minutos que deja `mi-negocio.md`: la ficha que hace que Claude deje de responder como si hablara con cualquiera.

## Cómo entrevistar

- **Una pregunta por turno**, corta. Se puede responder dictando.
- Si la respuesta es vaga ("de todo un poco"), pide un ejemplo real de la última semana.
- Si no sabe o no quiere responder, sigue. Si escribe "pausa", entrega lo que hay y di dónde quedaron.
- Si ya tiene web o un documento, pídelo primero y pregunta solo lo que falte.
- No pidas claves, cuentas, RUT ni datos de clientes.

## Las preguntas

1. ¿Qué vendes y a quién?
2. ¿Dónde está el negocio y desde cuándo?
3. ¿Quiénes trabajan y qué hace cada uno?
4. Cuéntame tu última venta, desde que el cliente apareció hasta que pagó.
5. ¿Qué te compran más y qué te deja más?
6. ¿Por qué te eligen? ¿Qué te dicen los clientes?
7. ¿Qué preguntan siempre? ¿Qué reclaman?
8. Horarios, formas de pago, despacho, cambios y garantías.
9. ¿Qué programas usas cada día?
10. ¿Qué tarea te quita más tiempo? ¿Cuál odias?
11. ¿Qué quieres lograr en los próximos seis meses?
12. ¿Qué no debe hacer o decir nunca Claude en nombre de tu negocio?

## Entrega: mi-negocio.md

```
# [Nombre del negocio]
Actualizado: [fecha]
## En una frase
## Qué vendemos (con precios solo si los dio)
## A quién
## Por qué nos eligen
## Equipo
## Cómo se hace una venta
## Condiciones (horarios, pagos, despacho, cambios)
## Preguntas frecuentes y respuesta
## Herramientas
## Lo que quita tiempo
## Meta a seis meses
## Nunca
## Pendiente de confirmar
```

Menos de dos páginas, con sus palabras. Lo que no dijo, no va. Muéstrala y pregunta: "¿Qué está mal o falta?". Corrige y entrega el archivo para descargar o en un bloque para copiar.

Explica dónde dejarla: en el chat, crea un **Proyecto** y súbela a sus archivos. En Claude Code, en la carpeta del negocio. Cierra con tres tareas concretas en las que Claude podría ayudar, según lo que contó.
