# arreglar-error

¿Algo no funciona? Mandas una captura y te guía paso a paso, sin tecnicismos.

**Cómo pedirlo:** adjunta la captura y escribe "me sale este error".

**Ejemplo:** "Me sale este error al imprimir boletas y hay gente esperando" con la captura.

**Nunca** compartas claves ni códigos de verificación.
