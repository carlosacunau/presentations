---
name: arreglar-error
description: "Úsalo siempre ante un error de computador, programa o página: guía un paso a la vez y detecta engaños. Con una captura, 'me sale un error', 'no funciona' o 'se quedó pegado'."
---

# Arreglar un error

La persona manda una captura y recibe los pasos para resolverlo, uno a la vez, sin tecnicismos.

## Paso 1. Lee la captura

Di qué ves: programa, mensaje exacto, qué estaba intentando. Si no se lee, pide otra. Si en la imagen hay claves o datos personales, avisa y no los repitas.

**Primero, ¿es una trampa?** Si pide llamar a un número, instalar algo para "limpiar virus", entrar con clave desde un enlace o pagar, dilo enseguida: "Esto parece un engaño. No llames, no instales, no pagues". Indica cerrar la ventana y entrar al servicio escribiendo su dirección.

## Paso 2. Pregunta solo lo necesario

Máximo dos preguntas: qué estaba haciendo y desde cuándo, o si es Windows, Mac o teléfono cuando no se ve.

## Paso 3. Resuelve

1. Qué significa, en una frase.
2. Causa más probable y cuánta seguridad tienes.
3. **Un paso por turno**, del más simple y seguro al más complejo. Di dónde hacer clic, con el nombre exacto, y qué debería ver después.
4. Pide captura del resultado y sigue desde ahí.

Antes de cualquier paso que cambie algo: qué cambia y cómo se vuelve atrás. Si existe búsqueda web, confirma en la ayuda oficial del programa.

## Nunca

- Pedir claves, códigos de verificación ni datos de tarjeta.
- Indicar borrar, formatear, restablecer, editar el registro o desactivar el antivirus sin respaldo confirmado y sin explicar la consecuencia.
- Hacer pegar comandos sin explicar qué hacen.
- Dar por resuelto algo que la persona no comprobó.

## Cuándo parar

Después de tres intentos sin avance, si hay riesgo de perder información, o si es banco, SII, factura electrónica o un equipo de la empresa: prepara el mensaje para soporte con qué pasó, mensaje exacto, qué se probó y captura.

## Cierre

Cuando funcione: qué era y cómo evitarlo, en dos líneas.
