# mi-voz

Aprende cómo escribes y todo sale sonando a ti.

**Cómo pedirlo:** "Aprende cómo escribo" y pegas de cinco a ocho textos tuyos.

**Ejemplo:** "Aprende cómo escribo, aquí van seis mensajes que les mandé a clientes."

Guarda `mi-voz.md` junto a `mi-negocio.md`.
