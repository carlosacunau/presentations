---
name: mi-voz
description: "Aprende cómo escribe la persona y arma mi-voz.md para que los textos suenen a ella. Úsalo con 'mi voz', 'aprende cómo escribo' o 'escribe como yo'."
---

# Mi voz

Aprende cómo escribe la persona y lo deja en `mi-voz.md`. Desde ahí, lo que Claude redacte para que ella lo firme suena a ella. Toma unos 10 minutos.

## 1. Junta muestras

Pide de cinco a ocho textos que **haya escrito ella**: correos a clientes, mensajes de WhatsApp de trabajo, una publicación, una respuesta a un reclamo. De varias situaciones. Sugiere borrar nombres y datos de clientes.

Con menos de tres, dilo: la ficha será provisoria. Si algún texto parece escrito por una IA o por otra persona, pregunta y déjalo fuera.

## 2. Mira cómo escribe

Solo lo que se repite en dos o más textos:
- Saludo y despedida, según a quién.
- Tú o usted.
- Largo de frases y de mensajes.
- Cómo da un precio, un plazo, una mala noticia, un no.
- Cómo pide algo y cómo agradece.
- Palabras y frases propias.
- Emojis, signos de exclamación, mayúsculas, listas.
- Lo que nunca hace.

## 3. Escribe mi-voz.md

```
# Cómo escribo
Actualizado: [fecha], con [N] textos
## En tres líneas
## Saludos y despedidas (con clientes, con el equipo)
## Cómo doy precios, plazos y malas noticias
## Frases mías
## Palabras que no uso
## Por canal (WhatsApp, correo, redes)
## Ejemplos (dos o tres, sin datos de nadie)
```

Frases propias sí. Nombres de clientes, montos y datos de contacto, nunca. Si un canal no tiene muestras, escribe "sin muestras".

## 4. Prueba

Escribe un mensaje corto de su trabajo con esa voz y pregunta: "¿Suena a ti? ¿Qué cambiarías?". Ajusta la ficha hasta su sí. Es normal que tome dos o tres vueltas.

Explica dónde dejarla: en un **Proyecto** del chat, junto a `mi-negocio.md`, o en la carpeta del negocio en Claude Code.

Para actualizarla, compara el borrador con lo que la persona terminó enviando y agrega esa diferencia.

## Límite

Solo la voz de la persona que lo pide o de su marca. No imites a otra persona para hacerse pasar por ella.
