# crear-skill

Le enseñas una tarea una vez y la hace igual siempre. Con este armas el skill número 33.

**Cómo pedirlo:** "Crea un skill para...".

**Ejemplo:** "Crea un skill para el informe que le mando cada lunes a mi socio" con dos informes anteriores.
