# crear-skill

Le enseñas una tarea una vez y la hace igual siempre. Con esta armas la skill número 33.

**Cómo pedirlo:** "Crea una skill para...".

**Ejemplo:** "Crea una skill para el informe que le mando cada lunes a mi socio" con dos informes anteriores.
