---
name: crear-skill
description: "Convierte una tarea repetida en una skill propia, lista para subir a Claude. Úsala con 'crea una skill', 'enséñate esta tarea' o 'quiero que lo hagas siempre igual'."
---

# Crear una skill

Se le enseña una tarea una vez y la hace igual siempre. Una skill es una carpeta con un archivo `SKILL.md`: la receta de un trabajo.

## Paso 1. ¿Merece una skill?

Sí, si se repite, tiene un resultado reconocible y la persona sabe cuándo quedó bien. Si es de una sola vez, haz la tarea directamente, sin skill. Si son tres tareas juntas, elige una.

## Paso 2. Entrevista, una pregunta por turno

1. ¿Qué tarea es y cada cuánto la haces?
2. ¿Qué recibes para empezar y qué entregas al final?
3. Muéstrame uno o dos resultados buenos. ¿Tienes uno malo?
4. Cuéntame los pasos de la última vez.
5. ¿Dónde se equivoca alguien nuevo?
6. ¿Cómo sabes que quedó bien?
7. ¿Qué no debe hacer nunca?
8. ¿Con qué palabras lo pedirías?

Con los ejemplos, señala qué tienen en común los buenos y qué les falta a los malos. Confirma: "¿Es una regla o fue casualidad?". Sugiere quitar datos de clientes de los ejemplos.

## Paso 3. Escribe SKILL.md

```
---
name: nombre-en-minusculas-con-guiones
description: "Qué hace. Úsala con 'frase 1', 'frase 2'."
---
# Título
## Lo que necesitas
## Pasos
## Entrega (formato exacto)
## Revisión antes de entregar
## Límites
```

Reglas: nombre de hasta 64 caracteres, sin tildes, espacios ni las palabras "claude" o "anthropic". Descripción de menos de 200 caracteres, con las frases que la persona usaría. Cuerpo de menos de una página: escribe lo que Claude no puede adivinar. Ninguna clave ni dato de clientes adentro.

## Paso 4. Prueba

Aplícala a un caso nuevo, distinto de los ejemplos. Compara con lo que la persona esperaba y corrige la receta, no solo el resultado. Repite hasta que el resultado sirva sin retoques.

## Paso 5. Entrega

Crea un ZIP con la carpeta adentro: `nombre-de-la-skill/SKILL.md`. Si no puedes crear archivos, da el texto y los pasos para hacerlo. En Claude: **Personalizar > Skills > + > Crear skill > Subir una skill** (los nombres del menú pueden cambiar). En Claude Code: carpeta `.claude/skills/nombre-de-la-skill/`.
