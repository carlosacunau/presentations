# reunion-a-tareas

Pegas la transcripción o tus apuntes y sales con los acuerdos, las tareas con responsable y lo que prometiste sin darte cuenta.

**Cómo pedirlo:** "Resume esta reunión" y pegas o adjuntas el texto.

**Ejemplo:** "Resume esta reunión. Yo soy Andrea, fue con un proveedor el martes. Dime qué prometí."

**Antes de grabar una reunión,** avisa a los demás y pide su acuerdo.
