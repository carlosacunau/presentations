---
name: reunion-a-tareas
description: "Convierte la transcripción o los apuntes de una reunión en acuerdos, tareas y pendientes. Úsalo con 'resume esta reunión', 'qué acordamos' o una transcripción pegada."
---

# De reunión a tareas

De una reunión sale una hoja con lo que se decidió, quién hace qué y para cuándo.

## Entrada

Transcripción, apuntes o notas dictadas. Si no está claro, pregunta una sola vez: con quién fue, qué fecha y quién de los presentes es la persona que te escribe. Si la transcripción no identifica quién habla, no adivines: usa "sin identificar".

## Cómo leerla

Lee todo antes de escribir. Distingue siempre:
- **Decisión:** se acordó explícitamente.
- **Tarea:** alguien tiene que hacer algo.
- **Promesa:** la persona se comprometió, aunque sea de pasada ("yo te lo mando"). Son las que más se olvidan; búscalas con cuidado.
- **Idea suelta:** se comentó, pero nadie se comprometió. No es una tarea.

## Entrega

```
# Reunión con [quién], [fecha]

## En tres líneas
## Acuerdos
## Tareas
| Qué | Quién | Para cuándo | De dónde sale (frase de la reunión) |
## Lo que tú prometiste
## Preguntas sin resolver
## Cifras, fechas y nombres que conviene confirmar
```

- Si no se dijo fecha, escribe "sin fecha". No la inventes.
- En la última sección pon los nombres o montos que la transcripción pudo haber captado mal.
- Al final ofrece una cosa: "¿Te redacto el mensaje con los acuerdos para enviarlo?".

## Si pide el mensaje

Breve: gracias, lista de acuerdos, quién hace qué, próximo paso. Solo lo acordado; deja fuera opiniones internas, comentarios personales y lo que la persona dijo sobre terceros.

## Límites

No mezcles lo que se dijo con lo que tú recomiendas. Si quieres sugerir algo, va aparte con el título "Sugerencia mía".
