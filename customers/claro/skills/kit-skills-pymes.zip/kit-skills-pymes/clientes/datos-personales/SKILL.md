---
name: datos-personales
description: "Revisa qué datos personales guarda un negocio en Chile y qué ordenar según la Ley 21.719. Úsala con 'ley de datos', 'datos personales', 'Ley 21.719' o 'política de privacidad'."
---

# Datos personales (Ley 21.719, Chile)

La Ley 21.719 modifica la Ley 19.628 y rige desde el 1 de diciembre de 2026. Esta skill ayuda a un negocio pequeño a ver qué datos guarda, qué sobra y qué falta. **No es asesoría legal**: dilo al empezar y al final, y nunca escribas "cumples con la ley".

## La idea que ordena todo

Para cada dato hay que poder responder: ¿para qué lo pido?, ¿qué me autoriza a usarlo?, ¿de verdad lo necesito? Si el dato no cambia lo que haces por el cliente, lo más sano es no guardarlo.

## Paso 1. Entrevista corta

Una sola pregunta por turno, aunque falten varias:
1. ¿A qué se dedica el negocio y a quién le vende?
2. ¿Por dónde entran datos? (formulario, WhatsApp, agenda, planilla, sistema de ventas, cámaras, currículos, remuneraciones)
3. ¿Qué datos pides en cada lugar?
4. ¿Dónde quedan y quién los ve? (personas y programas, incluidas las herramientas de IA)
5. ¿Guardas algo de salud, religión, origen, sindicato, vida u orientación sexual, huella o rostro, situación socioeconómica, o datos de menores?

Pide nombres de campos, **nunca los datos reales de los clientes**. Si los pega, avísale que no hace falta.

## Paso 2. Inventario

| Dato | Dónde entra | Para qué | Qué lo autoriza | Quién lo ve | Cuánto se guarda | Decisión |

Decisión: **mantener**, **dejar de pedir** o **consultar**. Si la persona no sabe para qué sirve un dato, escribe "finalidad no clara".

## Paso 3. Lo que conviene ordenar

Separa en tres: **Para ordenar ahora**, **Está bien encaminado** y **No se puede saber desde aquí**. Puntos a revisar:

- **Datos sensibles:** los de la pregunta 5. Regla general, requieren consentimiento expreso. Una nota suelta como "alérgica al tinte" ya es un dato de salud. La ley protege de forma especial a los menores de 14 años, y los datos sensibles de adolescentes menores de 16.
- **Consentimiento:** uno por finalidad, sin casillas ya marcadas, con registro de cuándo se dio, y que retirarlo sea tan fácil como darlo.
- **Información pública:** una página que diga qué datos usas, para qué, con quién los compartes y cómo ejercer derechos.
- **Derechos:** acceso, rectificación, supresión, oposición, portabilidad y bloqueo. Plazo de respuesta: 30 días corridos, prorrogable una sola vez hasta por otros 30. El bloqueo temporal se responde en dos días hábiles. Guarda prueba de cada respuesta.
- **Proveedores:** quien trata datos por encargo tuyo necesita un contrato que diga para qué, y no puede usarlos para otra cosa.
- **Incidentes:** si hay una filtración con riesgo para las personas, se informa a la Agencia sin demoras indebidas, y a los afectados cuando hay datos sensibles, de menores de 14 o financieros. Escribe hoy quién hace qué.
- **Decisiones automáticas:** si un sistema califica o rechaza personas, ellas pueden pedir explicación y revisión humana.

## Sobre las multas (solo si pregunta)

Infracción leve: amonestación escrita o hasta 5.000 UTM. Grave: hasta 10.000 UTM. Gravísima: hasta 20.000 UTM. Durante los primeros 12 meses la Agencia **puede** (no está obligada) aplicar una amonestación escrita a las empresas de menor tamaño. No uses las multas para asustar.

## Entrega

1. Resumen en cinco líneas.
2. Inventario.
3. Las tres listas del paso 3.
4. Cinco acciones para esta semana, de la más fácil a la más difícil.
5. Preguntas para un abogado.
6. La línea: "Esto no es asesoría legal. Confirma con un abogado y con el texto oficial en bcn.cl".

Si pide una política de privacidad o un texto de consentimiento, redacta un borrador solo con lo que está en el inventario y márcalo "BORRADOR, revisar con abogado".
