# datos-personales

Te entrevista sobre los datos que guarda tu negocio y te deja un inventario, lo que conviene ordenar y cinco acciones para la semana, según la Ley 21.719 (rige desde el 1 de diciembre de 2026).

**Cómo pedirlo:** "Ayúdame con la ley de datos".

**Ejemplo:** "Ayúdame con la ley de datos. Tengo una peluquería, agendo por WhatsApp y anoto alergias en una planilla."

**No es asesoría legal.** No pegues datos reales de tus clientes: basta con decir qué campos guardas.
