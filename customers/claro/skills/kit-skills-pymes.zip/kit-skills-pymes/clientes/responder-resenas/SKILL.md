---
name: responder-resenas
description: "Úsala siempre antes de responder una reseña de Google, buena o mala: respuesta pública sin exponer datos. Con 'responde esta reseña', 'me dejaron una estrella' o una captura."
---

# Responder reseñas

Una respuesta a una reseña la lee el cliente que la escribió, pero sobre todo la leen los que están decidiendo si comprar. Escribe para ambos.

## Antes de redactar

1. Lee la reseña (texto o captura) y clasifícala: positiva, mixta, negativa con razón, negativa discutible, o posiblemente falsa.
2. Si es negativa, pregunta a la persona qué pasó según su registro. No asumas que el cliente tiene razón ni que miente.
3. Si hay `mi-voz.md`, usa ese tono.

## Según el caso

- **Positiva:** agradece y menciona algo concreto de lo que dijo. Dos o tres líneas. Nada de respuestas idénticas para todos.
- **Mixta:** agradece lo bueno, reconoce lo que faltó y di qué cambia.
- **Negativa con razón:** reconoce el problema concreto, discúlpate una vez, di qué se corrigió y ofrece seguir por un canal privado.
- **Negativa discutible:** cuenta tu versión con hechos y calma, en una o dos frases. Sin ironía, sin discutir punto por punto.
- **Posiblemente falsa** (no está en los registros, describe otro negocio, trae insultos): respuesta breve y neutra ("no encontramos tu visita en nuestros registros, escríbenos para revisarlo") y explica que Google permite reportar reseñas que incumplen sus políticas.

## Reglas

- De 2 a 5 líneas. Usa el nombre del cliente solo si aparece publicado en la reseña.
- Nunca reveles datos del cliente: qué compró, cuánto pagó, su salud, su teléfono. La respuesta es pública.
- No ofrezcas regalos ni descuentos a cambio de cambiar o borrar una reseña.
- No inventes medidas que el negocio no haya tomado. Si falta el dato, deja `[FALTA: qué se corrigió]`.
- Nunca escribas reseñas falsas, ni positivas para el negocio ni negativas para otros.

## Entrega

La respuesta lista para copiar. Si vienen varias, entrégalas numeradas y con textos distintos entre sí. Al final, si un mismo reclamo se repite en tres o más reseñas, dilo en una línea: eso ya es un problema del negocio que hay que resolver.
