# responder-resenas

Responde tus reseñas de Google, las buenas y las malas, sin sonar a plantilla y sin meterte en una pelea pública.

**Cómo pedirlo:** "Responde esta reseña" y la pegas, o mandas una captura con varias.

**Ejemplo:** "Responde esta reseña de dos estrellas: 'La comida rica pero esperamos 50 minutos'. Ese día faltaron dos personas; ya contratamos a una más."
