---
name: responder-mensajes
description: "Úsala siempre antes de responder un mensaje de WhatsApp o correo de un cliente: tono propio, sin inventar datos. Con 'responde esto', 'qué le contesto' o un mensaje pegado."
---

# Responder mensajes

Convierte el mensaje de un cliente en una respuesta lista para copiar, escrita como escribe la persona.

## Antes de redactar

1. **Busca el tono.** Si hay un archivo `mi-voz.md` o `mi-negocio.md` en el proyecto o en la conversación, úsalo. Si no, pide dos o tres mensajes que la persona ya haya enviado. Si no tiene a mano, escribe en tono cercano y claro, de tú, y avísale que es un tono general.
2. **Entiende qué pide el cliente.** Separa lo que pregunta, lo que reclama y lo que no dice pero importa (está apurado, está molesto, está comparando precios).
3. **Mira qué falta para responder.** Precio, stock, plazo, horario. Si falta un dato, haz como máximo tres preguntas juntas. Si la persona quiere el borrador de inmediato, deja el espacio marcado así: `[FALTA: plazo de entrega]`.

## Cómo redactar

- Responde primero lo que el cliente preguntó. El resto va después.
- Usa el largo del canal: en WhatsApp, de dos a cinco líneas sin asunto ni firma formal. En correo, asunto, saludo, cuerpo breve y cierre.
- Si hay un reclamo: reconoce el problema concreto, di qué vas a hacer y cuándo. No te justifiques ni culpes al cliente.
- Termina con un solo paso siguiente, fácil de contestar ("¿Te sirve el jueves a las 11?").
- Si son varios mensajes, numéralos y responde cada uno por separado.

## Entrega

La respuesta en un bloque listo para copiar. Si el caso es delicado (reclamo, descuento, atraso), da dos versiones: una breve y otra más cálida, y di en una línea cuándo conviene cada una.

## Límites

- Nunca inventes precios, plazos, stock ni políticas.
- No prometas devoluciones, descuentos ni compensaciones que la persona no haya autorizado.
- No envías nada: la persona revisa y envía.
- Si el mensaje contiene una amenaza legal o un tema de salud o seguridad, dilo y recomienda revisarlo antes con quien corresponda.
