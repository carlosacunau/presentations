# responder-mensajes

Pegas el mensaje de un cliente y recibes la respuesta lista para copiar, con tu tono.

**Cómo pedirlo:** "Responde esto" y pegas el mensaje. También puedes mandar una captura de pantalla.

**Ejemplo:** "Responde esto: 'Hola, compré hace una semana y todavía no llega nada, ya es la segunda vez que escribo'. El pedido sale mañana."

**Queda mejor si** antes usas `mi-voz`.
